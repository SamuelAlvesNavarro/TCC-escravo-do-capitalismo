<?php
    header("Location: main/");
?>