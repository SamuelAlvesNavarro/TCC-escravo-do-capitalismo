<?php
    $ganhoDeMoedas = 50;
    $perdaDeMoedas = -50;
    $ganhoDePontosLeitor = 100;


    $salt_p_senha = "NoseSex";
    $salt = $salt_p_senha;
    $method = 'aes-128-cbc';
?>