<?php
    $ganhoDeMoedas = 50;
    $perdaDeMoedas = -50;
    $ganhoDePontosLeitor = 100;
?>