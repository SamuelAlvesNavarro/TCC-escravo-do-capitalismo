function acentral(){
    window.location="central.php";
}