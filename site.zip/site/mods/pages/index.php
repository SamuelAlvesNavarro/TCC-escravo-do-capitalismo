<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entrada</title>
    <link rel="stylesheet" href="../css/login.css">
</head>
<body>
    <div class="main">
        <h1>Aos Esgotos</h1>
        <form action="login.php" method="post">
            <input type="email" name="email" id=""><br>
            <input type="password" name="senha" id=""><br>
            <input type="submit" value="Enviar">
        </form>
    </div>
</body>
</html>