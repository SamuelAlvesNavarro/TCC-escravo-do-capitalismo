<?php
     //servidor --- > $pdo = new PDO('mysql:host=localhost;dbname=id20545858_pi', 'id20545858_samuel', 'Agx3((dO5ze*n-]Y');
    //escola ---> $pdo = new PDO('mysql:host=localhost;port=3307;dbname=pi', 'root', '');
    //casa ---> $pdo = new PDO('mysql:host=localhost;dbname=pi', 'root', '');
    
    $pdo = new PDO('mysql:host=localhost;port=3307;dbname=pi', 'root', '');
