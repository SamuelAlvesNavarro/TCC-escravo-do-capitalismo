<style>
.to-center{
    padding: 15px;
    position: fixed;
    top: 0;
    right: 50px;
    font-size: 30px;
    background: #121212;
    z-index: 1000;
}
.to-center a{
    color: white;
}
</style>
<div class='to-center'>
    <a href='main.php'><i class='fa-solid fa-home'></i></a>
</div>