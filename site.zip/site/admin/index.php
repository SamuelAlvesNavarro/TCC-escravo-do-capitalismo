<?php
    header("Location: ../main/pages/");
?>