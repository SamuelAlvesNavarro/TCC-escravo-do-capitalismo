<?php
    header("Location: ../../")
?>